var availbleServices = [
{
"id":"1",
"name": "JavaScript Tutorial",
"duration":"1",
"price": "2",
"curency":"E",
"description":"R",
"id_service_categories":"9"
},
{
"id":"2",
"name": "HTML Tutorial",
"duration":"3",
"price": "4" ,
"curency":"E",
"description":"R",
"id_service_categories":"9"
},
{
"id":"2",
"name": "CSS Tutorial",
"duration":"5",
"price": "6" ,
"curency":"E",
"description":"R",
"id_service_categories":"9"
},
{
"id":"2",
"name": "Museum",
"duration":"7",
"price": "8" ,
"curency":"E",
"description":"R",
"id_service_categories":"9"
}
];
