angular.module('starter.calendar', [])

.controller('CalendarCtrl', function($scope, $stateParams) {

  $scope.availbleServices = availbleServices;
});
